.. 1 documentation master file, created by
   sphinx-quickstart on Wed Feb  2 17:08:42 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to 1's documentation!
=============================
Zadanie 1
=========

Studium przypadku
-----------------


Podstawowe cechy języka Python:

• język programowania wysokiego poziomu,

• język skryptowy, do wykonania wykorzystuje interpreter,

• popularne implementacje:

       CPython (C/C++),

       Jython (Java),

       IronPython (.NET),

       PyPy (Python),

• bardzo duża popularność w zastosowaniach naukowych,
• IPython (popularna interaktywna implementacja interpretera)

Python jest to język programowania wysokiego poziomu ogólnego przeznaczenia, o rozbudowanym pakiecie bibliotek standardowych, którego ideą przewodnią jest czytelność i 
klarowność kodu źródłowego. Jego składnia cechuje się przejrzystością i zwięzłością.
Python rozwijany jest jako projekt Open Source zarządzany przez Python Software 
Foundation, która jest organizacją non-profit. 

Studium przypadku

W przeprowadzonym studium przypadku zdecydowano się wykorzystać pakiet Anaconda, rozwijany przez firmę Continuum Analytics. Wyboru tego dokonano, mając na uwadze następujące jego zalety:

- dostępność bezpłatnych wersji przeznaczonych dla różnych systemów operacyjnych (Windows, Linux, OS X), w tym także obrazów maszyn wirtualnych przygotowanych dla różnych dostawców usług chmurowych IaaS (m.in. Amazon AWS i Microsoft Azure),
- dostępność „od zaraz” w formule usługi chmurowej SaaS,
- interaktywną powłokę interpretera IPython udostępnioną za pośrednictwem notatnika  Jupyter, pozwalającą na tworzenie hybrydowych dokumentów złożonych z komórek zawierających m.in. hipertekst i kod źródłowy, który może być wykonywany bezpośrednio w środowisku przeglądarki internetowej,
- narzędzie Conda znacząco ułatwiające zarządzanie modułami,
- ponad 300 dołączonych specjalistycznych bibliotek.

Do analizy wybrano autentyczne wyniki testu zaliczeniowego z podstaw programowania komputerów przeprowadzonego wśród studentów I roku kierunku informatyka i ekonometria na Wydziale Nauk Ekonomicznych i Zarządzania Uniwersytetu Szczecińskiego (rok akademicki 2012/2013). Analizie poddano 48 wypełnionych formularzy testowych, które na potrzeby publikacji zanonimizowano.

Zasady przeprowadzania
----------------------

Zasady przeprowadzenia testu były następujące:

1) Blok główny stanowiło 25 pytań, dla każdego podano cztery warianty odpowiedzi,
zawsze tylko jeden wariant był prawidłowy, a jeden wśród nieprawidłowych („bardzo zły”) zawierał odpowiedź nielogiczną bądź taką, której wybór świadczył o tym, że student nie dysponuje podstawową wiedzą z przedmiotu,

2) Studenci mogli zaznaczyć jedną, dwie lub trzy odpowiedzi i otrzymać odpowiednio jeden, pół lub jedną trzecią punktu, jeżeli wśród wybranych wariantów był prawidłowy,
jeżeli wśród wybranych wariantów był „bardzo zły”, odbierano jeden punkt (niezależnie od liczby wybranych wariantów),

3) Zaznaczenie wszystkich czterech wariantów traktowano jako brak odpowiedzi (0 punktów).

Możliwość wyboru więcej niż jednej odpowiedzi wprowadzono po to, by móc ocenić pewność studentów co do własnej wiedzy. „Bardzo złe” warianty odpowiedzi miały zaś zmotywować ich do głębszego przemyślenia treści nawet tych pytań, na które nie znali prawidłowej odpowiedzi, i albo wskazania trzech odpowiedzi uznanych za prawdopodobne, albo zupełnego odstąpienia od odpowiedzi na dane pytanie. 


Główne cele przeprowadzania
---------------------------

Za główne cele przeprowadzenia analizy wyników testu należy uznać:

1) ocenę jakości samego testu, i - w konsekwencji - udoskonalenie go poprzez zmodyfikowanie pytań zbyt łatwych lub zbyt trudnych oraz zadbanie o możliwie pełne i równomierne pokrycie pytaniami zarówno zakresu merytorycznego wykładów, jak i oczekiwanych efektów kształcenia;
2) ocenę doboru i formy przekazywanych treści dydaktycznych, stanowiących podstawę poszczególnych pytań ujętych w teście poprzez identyfikację zakresu merytorycznego treści, z którego opanowaniem studenci szczególnie sobie nie poradzili, i - w konsekwencji - udoskonalenie materiałów dydaktycznych poprzez np. jaśniejsze sformułowanie przekazu czy dodanie przykładów lub ćwiczeń do samodzielnego wykonania;
3) wyjaśnienie przyczyn uzyskania przez poszczególnych studentów określonych wyników, w szczególności: zbadanie zależności między faktem uczenia się (np. obecność na określonych wykładach) a uzyskanymi w teście wynikami oraz wykrycie zbieżności pomiędzy odpowiedziami różnych studentów.

W dalszej części artykułu przedstawione zostaną ukierunkowane na powyższe cele przykłady analizy graficznej wyników testu przeprowadzonej z wykorzystaniem oprogramowania Anaconda, opartego na języku Python. Analiza obejmowała zbadanie: poprawności i pewności odpowiedzi udzielonych na poszczególne pytania, zależności wyników od obecności na wykładach, rodzaju pytania i zakresu treści, których ono dotyczy, oraz stopnia podobieństwa odpowiedzi udzielanych przez różnych studentów. 



Niezależnie od tego, czy test przeprowadzono elektronicznie, czy tylko wprowadzono do komputera jego wyniki (jak było to w omawianym przypadku), prostą i wygodną formę ich reprezentacji stanowi plik tekstowy zawierający umieszczone w kolejnych wierszach (odpowiadających poszczególnym studentom) ciągi wartości (odpowiadające poszczególnym pytaniom) rozdzielone przecinkami. Kod wczytujący tabelę wyników i wydzielający z niej do osobnych tabel informacje zawarte w dodatkowych kolumnach (obecności studentów na kolejnych wykładach) i wierszach (kolejno: prawidłowe i „bardzo złe” warianty odpowiedzi, rodzaj pytania oraz numer wykładu, którego dotyczyło) zawiera listing pierwszy.

          Listing pierwszy:

.. figure:: 11.JPG
 

          Analiza odpowiedzi na poszczególne pytania testowe
          
Dość złożone reguły testu skomplikowały sprawdzanie poprawności i pewności udzielonych odpowiedzi (patrz listing drugi). Mimo to warto zwrócić uwagę np. na prostotę zapisu operacji przemnożenia wszystkich danych w kolekcji przez skalar.

          Listing drugi Sprawdzanie poprawności i pewności udzielonych odpowiedzi.
          
          
.. figure:: 22.JPG
          
          
          
            Uzyskanie specyficznego wyglądu histogramu (m.in. wyświetlenie liczby trafnych odpowiedzi powyżej, a nietrafnych - poniżej osi poziomej) wymaga kilkunastu wierszy kodu (patrz listing trzeci).



           
        
.. figure:: zdjecie33.JPG





        Listing 3



.. figure:: 44.JPG


        Odpowiedzi udzielone na poszczególne pytania testu
        

Analizując diagram, można zauważyć przede wszystkim brak poprawnych odpowiedzi na pytanie 14. Również pytania 16, 18 i 23 okazały się dla zdecydowanej większości studentów zbyt trudne. Z kolei pytanie 3 okazało się zbyt proste, podobnie jak pytania 1 i 21 (te dwa ostatnie w nieco mniejszym stopniu). Spostrzeżenia te uwzględniono przy opracowywaniu pytań testowych w kolejnych latach. 

Analiza odpowiedzi na pytania dotyczące poszczególnych wykładów

Pytania zawarte w teście powinny odzwierciedlać możliwie w pełni i równomiernie tematykę wykładów. W ocenie, na ile udało się to osiągnąć, pomocna jest wizualizacja ukazująca pokrycie wykładów pytaniami.

Dodatkowo odpowiedzi udzielane na pytania przypisane do danego wykładu pośrednio wskazują poziom opanowania przez studentów wiedzy z obszaru, którego dotyczył wykład. Gdy poziom ten jest niski, stanowi to przesłankę do weryfikacji treści i formy wykładu.

Zamierzone efekty nauczania dotyczą nie tylko wiedzy, ale też opanowania różnego typu efektów kształcenia. Interesujące jest zatem, jak poprawność odpowiedzi prezentowała się po uwzględnieniu rodzaju pytań. W literaturze można spotkać się z różnymi taksonomiami pytań testowych dotyczących programowania komputerów. Tu pytania podzielono na dwa rodzaje, z których każdy obejmował po dwa podrodzaje:

    pytania weryfikujące wiedzę:
        wymagające wskazania dobrej odpowiedzi wśród złych,
        wymagające wskazania złej odpowiedzi wśród dobrych; 
    pytania weryfikujące umiejętność prawidłowego zastosowania wiedzy:
        wymagające rozumienia (np. kodu źródłowego fragmentu programu),
        wymagające (prócz rozumienia kodu) przeprowadzenia prostych obliczeń. 

Wszystkie omawiane informacje przedstawiono na pojedynczym diagramie rozproszenia. Odpowiedzi na poszczególne pytania mają na nim formę kółek oznaczonych numerami pytań, o kolorze zależnym od rodzaju pytania. Ich pionowa pozycja zależy od odsetka punktów przyznanych studentom za dane pytanie (spośród wszystkich możliwych do zdobycia za nie), poziomą zaś wyznacza numer wykładu, którego treści ono dotyczyło. Przy każdym kółku umieszczono strzałkę pokazującą, o ile lepiej od przeciętnej na dane pytanie odpowiadali studenci obecni na wykładzie, którego ono dotyczyło (strzałka skierowana w dół oznacza, że odpowiadali oni gorzej). Ponadto kółka oznaczające pytania dotyczące tego samego wykładu starano się rozsunąć w poziomie, tak by zmniejszyć ryzyko nachodzenia ich na siebie - co, wraz z niestandardowym rozmieszczeniem oznaczeń na osi odciętych, dodatkowo skomplikowało kod źródłowy służący do wygenerowania wykresu. 

        Listing czwarty Prezentacja wyników w kontekście zakresu treści i rodzaju pytania.
        
        
.. figure:: zdjecie.JPG   


Rysunek 2. Przyznane punkty według zakresu treści i rodzaju pytania


.. image:: zdjecie1.JPG  

Patrząc na rysunek, trudno dostrzec, by określony rodzaj pytania czy wykład wiązał się ze szczególnie niskim lub wysokim poziomem odpowiedzi. Diagram ujawnia natomiast nierówną liczbę pytań dotyczących poszczególnych wykładów oraz wyraźną przewagę pytań teoretycznych w przypadku wykładów początkowych i pytań praktycznych w przypadku wykładów końcowych. Są to potencjalnie słabe strony testu - wskazują, które elementy wymagają weryfikacji. W przypadku omawianego testu nierównomierność okazała się uzasadniona: treść wykładu - np. definicje i klasyfikacje  albo przykłady kodu  - sprzyjała bowiem formułowaniu pytań jednego rodzaju (dotyczących teorii lub praktyki), a waga poszczególnych wykładów nie była taka sama - np. składnia języka  a kodowanie danych.

Jeśli chodzi o wpływ obecności studentów na poprawność ich odpowiedzi, dla 16 z 25 pytań obecni na dotyczących ich wykładach studenci uzyskali wyniki lepsze od nieobecnych. W przypadku pytań 1 i 5, gdzie różnica na korzyść nieobecnych była wyraźnie widoczna, dokonano weryfikacji formy prezentacji treści, których dotyczyły te pytania, nie dopatrzono się jednak błędów - należy mieć na uwadze, że:

1. test przeprowadzono na zakończenie semestru, a pytania te dotyczyły treści dwóch wykładów z początku semestru,
2. treść wykładów była dostępna dla wszystkich studentów za pośrednictwem platformy e-learningowej,
3. wykłady stanowiły tylko jedną z form nauczania (obok laboratoriów i pracy samodzielnej).

Analiza odpowiedzi poszczególnych studentów
-------------------------------------------

Jednym z podstawowych pytań odnoszących się do wyników testu jest pytanie o wzajemne podobieństwo odpowiedzi udzielanych przez różnych studentów. Listing 5 prezentuje kod źródłowy funkcji obliczającej wartość średniego współczynnika podobieństwa Jaccarda pomiędzy odpowiedziami udzielonymi na wszystkie pytania testowe przez dwóch studentów. 

        Listing 5. Obliczanie współczynnika podobieństwa odpowiedzi dwóch studentów.
        

.. image:: Zdjecie2.JPG  

W celu przejrzystego rozróżnienia stopni podobieństwa można wykorzystać pseudokolorowanie. W dotychczas omówionych przykładach starano się precyzyjnie osiągnąć zamierzony cel, co wydłużało kod źródłowy. Aby pokazać, że do skutecznej wizualizacji danych wystarczy niewielka liczba poleceń języka Python, w ostatnim przykładzie zrezygnowano z tytułu i opisów osi oraz modyfikacji domyślnych ustawień (poza ustaleniem górnych granic przedziałów). Odpowiedni kod źródłowy zamieszczono na listingu 6. 





        Listing 6. Prezentacja podobieństwa odpowiedzi wszystkich par studentów.
        
        
        
.. figure:: Zdjecie3.JPG



        Rysunek 3. Stopień podobieństwa odpowiedzi udzielanych przez studentów.
        
        
        
.. image:: Zdjecie4.JPG
        

Uzyskany w wyniku jego wykonania wykres  pokazuje, że stopień podobieństwa odpowiedzi udzielanych przez studentów był niski. Należy tu zauważyć, że możliwość wskazania dla każdego pytania więcej niż jednej odpowiedzi powoduje zmniejszenie prawdopodobieństwa przypadkowej zgodności odpowiedzi różnych studentów.

Dzięki jaskrawoczerwonej barwie zwraca uwagę pięć par studentów, które wyróżniają się na tym tle: (4, 31); (6; 9); (8, 16); (15, 22) i (19, 26). Wypada tu wyjaśnić, że choć odczytanie współrzędnych oznaczających numery studentów  byłoby trudne, to oryginalny wykres wyświetlony z poziomu interpretera języka Python pozwala na ich łatwe odczytanie po przesunięciu wskaźnika myszy do odpowiedniego punktu wykresu. Możliwe jest też wtedy m.in. powiększanie wykresu i przesuwanie jego widocznego fragmentu, a także zapisanie go w jednym z popularnych formatów grafiki rastrowej lub wektorowej.

Przypadek oczywisty stanowi sytuacja, w której różni studenci odpowiadali pewnie i perfekcyjnie (a zatem musieli też zakreślać te same - dobre odpowiedzi). Przypadek ten nie dotyczył jednak żadnej z wymienionych pięciu par studentów, dlatego przyczyn zgodności ich odpowiedzi należałoby się doszukiwać albo we wspólnym uczeniu się z tych samych materiałów (np. znalezionych w internecie), które zawierały braki lub błędy merytoryczne, lub - co niestety bardziej prawdopodobne - „ściąganiu” studentów od siebie (do weryfikacji tego przydatna byłaby informacja o miejscach, które studenci zajmowali podczas testu). 

Analiza graficzna danych edukacyjnych nie musi być prowadzona w oparciu o język Python, z wykorzystaniem oprogramowania Anaconda lub analogicznego. Naturalne rozwiązanie alternatywne stanowi wykorzystanie popularnego programu Microsoft Excel. Poniżej wskazane zostaną przesłanki przemawiające za wyborem Anacondy. Podstawowa różnica między tymi dwoma środowiskami polega na domyślnym sposobie dochodzenia do pożądanego celu: poprzez jego wyspecyfikowanie w postaci programu w języku Python lub użycie interaktywnego kreatora wykresów. Choć Anaconda również dysponuje analogicznym narzędziem interaktywnym (poprzez bibliotekę Pivottablejs, warto mieć świadomość zalet posługiwania się kodem źródłowym. Za trzy najważniejsze z nich należy uznać:

1) zakres adaptacji formy wizualizacji danych, dalece wykraczający poza możliwości narzędzia interaktywnego;
2) szybkość wprowadzania zmian: dzięki pętlom i instrukcjom warunkowym możliwe jest zapisanie w kilku wierszach kodu źródłowego reguł pozwalających uniknąć nawet kilkudziesięciu minut mozolnego wybierania i modyfikowania ustawień wizualizacji drobnych elementów wykresu;
3) łatwość ponownego wykorzystania: nawet gdy rozszerza się zakres danych wejściowych czy dodaje do wykresu kolejną zmienną, wymaga to jedynie niewielkiej modyfikacji kodu; w przypadku narzędzia interaktywnego istotna zmiana treści często oznacza konieczność ponownego ręcznego dostosowania szczegółowych ustawień wizualizacji.

Jako że program Microsoft Excel również posiada wbudowany interpreter języka programowania VBA (Visual Basic for Applications), który można traktować jako rozwiązanie alternatywne dla interpretera języka Python dostępnego w oprogramowaniu Anaconda, dokonano porównania tych dwóch rozwiązań w oparciu o dziewięć kluczowych kryteriów użytkowych. Jego rezultaty, zamieszczone w tabeli pierwszej, dobitnie pokazują wyższość rozwiązania opartego na języku Python. 


Wnioski
---------


Opisane studium przypadku pokazuje, że graficzna analiza danych może być z powodzeniem wykorzystana do analizy wyników testów i dostarczyć wielu informacji użytecznych w kontekście procesu doskonalenia metod i środków nauczania oraz weryfikacji jego wyników. Jednocześnie zademonstrowano użyteczność do tego celu interpretera języka Python. Język ten, dzięki dostępności bibliotek obliczeniowych (np. NumPy) i wizualizacyjnych (np. Matplotlib), stwarza szerokie możliwości prowadzenia analizy danych edukacyjnych. Szczególną wygodę korzystania z niego zapewnia oprogramowanie Anaconda, obejmujące, prócz samego interpretera i pakietu bibliotek, notatnik Jupyter oraz narzędzie zarządzania modułami Conda. Przeprowadzone porównanie ujawnia liczne przewagi tego środowiska nad programem Microsoft Excel. 

Zadanie 2
==========


Zadanie 2a
-----------


Dobranym przez nas rozkładem prawdopodobieństwa jest rozkład normalny zwany także rozkładem Gaussa lub też krzywą Gaussa. Obrazuje on prawdopodobieństwo z jakim dana wartość może znajdować się w określonym wcześniej przedziale, lub w skrócie skupienie wokół średniej danych. Można go użyć na przykład do przeanalizowania  danych na temat rozmiarów obuwia, dzięki czemu jeśli jesteśmy producentem obuwia wiemy jakie wielkości buta są najbardziej dla nas opłacalne. Żeby to zobrazować przygotowałem wykres używając Pythona z danych wcześniej wygenerowanych losowo. Z wykresu jesteśmy w stanie odczytać że jeśli byśmy chcieli docierać do ponad 50% klientów, musimy produkować obuwie o wielkości w zakresie ok. od 37 do 43.


.. image:: Wykres.jpg


Wykres został wygenerowanych funkcją z biblioteki numpy-aja,  a jego parametry były ustawione na kolejno:

Centrum rozkładu: 40
Skala rozkładu: 4
Wielkość próbki: 1000


Dane uzyskane w procesie są umieszczone w formie tabeli i zapisane do pliku zad2a o rozszerzeniu csv. Rozszerzenie CSV idealnie nadaje się do konstrukcji tabelarycznych dodatkowo jest zalecanym rozszerzeniem do realizowania takich operacji. Zapis CSV pozwala również na łatwą edycję danych poprzez import/export danych przez arkusze kalkulacyjne np. MS Excel.

Zadanie2b
------------

Dane do Zadania2b pobrane zostały z strony dane.gov.pl. Prezentują one liczbę zgonów w Polsce w roku 2021, w poszczególnych tygodniach roku. Plik został pobrany w formacie csv, a następnie wgrany na serwer. Za pomocą kodu tworzony jest wykres, przedstawiający uzyskane dane na przestrzeni roku.


.. image:: Wykres1.JPG

Na wykresie można zauważyć znaczący wzrost zgonów w poszczególnych okresach. Jako, że dane są z roku 2021 na ich istotny wpływ ma pandemia COVID. Można wywnioskować, że okresy w których ilość tych śmierci się istotnie zwiększają pokrywają się z okresami występowaniem fal koronawirusa kiedy odnototwywało się najwięcej zakażeń oraz zgonów, a co za tym idzie możemy powiedziećm, że na wykresie wysępuje sezonowość. 




Zadanie 3
==============


Komunikacja miejska
--------------------


W programie zastosowana została wymieniona poniżej konwencja danych:
Numery przystanku, linii oraz pojazdów są to liczby od 1 do 10.
Format daty jest następujący: Dzień/Miesiąc/Rok
Format czasu to Godziny:Minuty.

W celu sprawdzenia poprawności danych wprowadzanych zostały użyte funkcje .isdigit() oraz własnoręcznie przygotowana funkcja sprawdzająca poprawność czasu oraz daty w postaci podanej poniżej:


.. image:: Kod.jpg


Funkcje te sprawdzają czy po pierwsze wszystkie liczby są rozdzielone poprawnie za pomocą backslasha oraz czy wpasowują się w format daty. Jeśli któraś z części zwróci błąd skrypt  automatycznie zwróci wartość False.
W przypadku dostania wartości False program automatycznie przydzieli błędne dane żeby zostały przypisane do specjalnego pliku na właśnie niepoprawne wpisy.
Dzieje się tak za pomocą prostego warunku If który można zobaczyć poniżej.


.. image:: Kod1.jpg

Jako że funkcja jest dość spora pozwoliliśmy sobie na zamieszczenie bardziej czytelnego obrazu poniżej.


.. image:: Kod3.jpg


Jeśli wszystkie warunki zwrócą wartość TRUE program przystąpi do zapisania poprawnych danych do Sqlite. Jeśli jednak dane się nie zgadzają, zostają wysłane do specjalnego dla nich pliku (jak to zostało wyżej już opisane) o nazwie file_out.

Github
-----------

Wszystkie materiał dostępne są na: 

git@github.com:Damian1919/RepozytoriumZaliczeniowe.git

.. toctree::
   :maxdepth: 2
   :caption: Contents:



